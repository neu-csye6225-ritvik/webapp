
// import health from "../model/mod-health.js";

// export const getCollection = async function getUser(id) {
//   try {
//     const userData = await user.findById(id).exec();
//     return userData;
//   } catch (err) {
//     console.error(`Error: ${err}`);
//   }
// }

