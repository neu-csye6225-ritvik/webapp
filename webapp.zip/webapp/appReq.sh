#!/bin/bash 
npm uninstall bcrypt

npm install bcrypt

node server.js
